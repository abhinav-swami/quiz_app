const express = require("express");
const app = express();
const bodyParser = require("body-parser");
const cors = require("cors");
const mongoose = require("mongoose");
const PORT = process.env.PORT || 4000;

//models
let User = require("./models/user.model");
let Response = require("./models/response");

//assets
let quizData = require("./assets/quiz.js");

app.use(cors());
app.use(bodyParser.json());

mongoose.connect("mongodb://127.0.0.1:27017/quizapp", {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});
const connection = mongoose.connection;

connection.once("open", function () {
  console.log("MongoDB database connection established successfully");
});

// Routes

app.get("/", (req, res) => {
  res.send("backend home");
});

app.post("/signup", (req, res) => {
  console.log(req.body);

  User.findOne({ user_mobno: req.body.user_mobno }, (err, userdata) => {
    if (!userdata) {
      var newUser = new User({
        user_fname: req.body.user_fname,
        user_lname: req.body.user_lname,
        user_mobno: req.body.user_mobno,
        user_pwd: req.body.user_pwd,
      });

      newUser.save(function (err, product) {
        if (err) {
          console.log(err);
        } else {
          res.status(200).json({ user: "user added successfully" });

          console.log("WE JUST SAVED A user TO THE DB:");
          console.log(newUser);
        }
      });
    } else {
      res.status(200).json({ user: "User already register" });
    }
  });
});

app.post("/login", (req, res) => {
  User.findOne(
    { user_mobno: req.body.user_mobno, user_pwd: req.body.user_pwd },
    (err, userdata) => {
      if (err) {
        return res.send({ status: 500, message: "Something went wrong." });
      } else {
        console.log(userdata);
        return res.send({
          status: 200,
          data: userdata,
        });
      }
    }
  );
});

app.get("/getQuiz", (req, res) => {
  let quizArray = quizData.questions();

  console.log(quizArray);

  quizArray.sort((a, b) => Math.random() - 0.5);

  return res.send({
    status: 200,
    data: quizArray.splice(0, 10),
  });
  user;
});

app.post("/submitResponse", (req, res) => {
  console.log(req.body);

  User.findOne({ user_mobno: req.body.user_mobno }, (err, userdata) => {
    if (!userdata) {
      var newUser = new User({
        user_fname: req.body.user_fname,
        user_lname: req.body.user_lname,
        user_mobno: req.body.user_mobno,
        user_pwd: req.body.user_pwd,
      });

      newUser.save(function (err, product) {
        if (err) {
          console.log(err);
        } else {
          res.status(200).json({ user: "user added successfully" });

          console.log("WE JUST SAVED A user TO THE DB:");
          console.log(newUser);
        }
      });
    } else {
      res.status(200).json({ user: "User already register" });
    }
  });
});

app.listen(PORT, () => {
  console.log("server is started on port " + PORT);
});
