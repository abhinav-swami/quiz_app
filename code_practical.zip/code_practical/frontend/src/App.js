import React from "react";
import { BrowserRouter as Router, Switch, Route, Link } from "react-router-dom";
import logo from "./logo.svg";
import "./App.css";

import Login from "./components/forms/login.js";
import Signup from "./components/forms/signup.js";
import Homepage from "./components/homepage.js";
import Submitquiz from "./components/submitquiz.js";
import Quizhistory from "./components/quizhistory.js";
import Quizdetails from "./components/quizdetails.js";

import "bootstrap/dist/css/bootstrap.min.css";
import Getquiz from "./components/getquiz";

function App() {
  return (
    <Router>
      <nav className="navbar navbar-expand-sm bg-dark navbar-dark sticky-top container">
        <a className="navbar-brand" href="/">
          HOMEPAGE
        </a>

        <ul className="navbar-nav mr-auto">
          <li className="nav-item active">
            <a className="nav-link" href="/quizhistory">
              Quiz History
            </a>
          </li>
          <li className="nav-item active">
            <a className="nav-link" href="/quizsubmit">
              Quiz Submit page
            </a>
          </li>
          <li className="nav-item active">
            <a className="nav-link" href="/quizdetails">
              Quiz details page
            </a>
          </li>

          <ul className="navbar-nav">
            <li className="nav-item active ">
              <Link to="/login" className="nav-link ">
                Login
              </Link>
            </li>
            <li className="nav-item active">
              <Link to="/signup" className="nav-link ">
                Sign Up
              </Link>
            </li>
          </ul>
        </ul>
      </nav>

      <Switch>
        <Route exact path="/">
          <Homepage />
        </Route>
        <Route path="/login">
          <Login />
        </Route>
        <Route path="/signup">
          <Signup />
        </Route>
        <Route path="/quizsubmit">
          <Submitquiz />
        </Route>
        <Route path="/quizhistory">
          <Quizhistory />
        </Route>
        <Route path="/quizdetails">
          <Quizdetails />
        </Route>
        <Route exact path="/getQuiz">
          <Getquiz />
        </Route>
      </Switch>
    </Router>
  );
}

export default App;
