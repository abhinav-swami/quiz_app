import React, { Component } from "react";
import axios from "axios";

export default class Getquiz extends Component {
  constructor(props) {
    super(props);
    this.state = { quizdata: [] };
  }

  componentDidMount() {
    axios
      .get("http://localhost:4000/getQuiz")
      .then((response) => {
        console.log(response.data.data);

        this.setState({ quizdata: response.data.data });
        console.log(this.state);
      })
      .catch(function (error) {
        console.log(error);
      });
  }

  questionsList() {
    return this.state.quizdata.map(function (currentquestionarray, i) {
      return (
        <div key={i} className="card col mb-3">
          <h1>Question: {currentquestionarray.question}</h1>
          <p>
            <em>select your answer below</em>
          </p>
          <p>1: {currentquestionarray.answers[0]}</p>
          <p>2: {currentquestionarray.answers[1]}</p>
          <p>3: {currentquestionarray.answers[2]}</p>
          <p>4: {currentquestionarray.answers[3]}</p>
        </div>
      );
    });
  }

  render() {
    return (
      <>
        <div className="jumbotron container ">{this.questionsList()}</div>
      </>
    );
  }
}
