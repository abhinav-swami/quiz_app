import React, {Component} from 'react';

export default class Submitquiz extends Component{
	render() {
		return(
			<>
			
			<div className='jumbotron container mx-auto row'>
				
				<div className='text-center py-5'>
					<h1 className=''>Thank You, your quiz is submitted successfully</h1>
				</div>
				<div>
					<h3>Your Quiz ID Is : <strong>XONGO00001 </strong> </h3>
					<h3 className='my-5'>Your Quiz Score Is : <strong>70 </strong></h3>
				</div>
				<br />
				<div className='ml-auto my-5'>
					<button className='btn btn-dark'>Show quiz History</button> 
					<button className='btn btn-dark mx-5 ' href="/">Start Quiz</button> 
					<button className='btn btn-dark'>Log out</button> 
				</div>
				
			</div>
			</>
		)
	}
}