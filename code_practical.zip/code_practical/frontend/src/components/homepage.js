import React, { Component } from "react";
import { BrowserRouter as Router, Switch, Route, Link } from "react-router-dom";
import Getquiz from "./getquiz";

export default class Homepage extends Component {
  render() {
    return (
      <Router>
        <div className="jumbotron container mx-auto row my-auto">
          <div className="col-sm-4">
            <img
              src="https://i.pinimg.com/originals/51/f6/fb/51f6fb256629fc755b8870c801092942.png"
              className="px-3 img-fluid"
              alt="userimage"
            />
          </div>

          <div className="col-sm-8 px-5">
            <h1>Welcome Guest</h1>
            <p>
              Xongolabs wishes you HAPPY BIRTHDAY!!!!!
              <i
                className="fa fa-birthday-cake ml-4"
                aria-hidden="true"
                style={{ fontSize: 40 + "px" }}
              ></i>
            </p>
            <button className="btn btn-dark btn-lg">
              <a href="/getQuiz">Start Quiz</a>
            </button>
          </div>
        </div>

        <Switch>
          <Route exact path="/getQuiz">
            <Getquiz />
          </Route>
        </Switch>
      </Router>
    );
  }
}
