import React, { Component } from 'react';
import axios from 'axios';


export default class Login extends Component {
	constructor(props) {
		super(props);

		this.onChangeUserMobNo = this.onChangeUserMobNo.bind(this);
		this.onChangeUserPwd = this.onChangeUserPwd.bind(this);
		
		this.onSubmit = this.onSubmit.bind(this);

		this.state = {
			user_mobno: '',
			user_pwd: '',
		};
	}
	onChangeUserMobNo(e) {
	this.setState({
	user_mobno : e.target.value
	});
	}

	onChangeUserPwd(e) {
	this.setState({
	user_pwd: e.target.value
	});
	}
	
	onSubmit(e) {
	e.preventDefault();

	console.log(`user logged in`);
	console.log(`mobno: ${this.state.user_mobno}`);
	console.log(`pwd: ${this.state.user_pwd}`);
	
	const userdata = {
           
	user_mobno: this.state.user_mobno,
	user_pwd: this.state.user_pwd
	}

	axios.post('http://65.0.45.81:55337/login', userdata)
	.then(res => console.log(res.data));

			this.setState({
            
			user_fname:'',
			user_lname:'',
			user_mobno: '',
			user_pwd: '',
			})
	}
	
	
	
	render() {
		return (
			<div className="login-form jumbotron container ">
				<form action="/login" method="post" className="px-5 mx-5">
					<h2 className="text-center mb-5">Log in</h2>

					<div className="form-group row">
						<label for="usermobno" className="col-sm-2 col-form-label">
							Mobile No.
						</label>
						<div className="col-sm-10">
							<input
								type="Number"
								className="form-control"
								id="usermobno"
								value={this.state.user_pwd}
	onChange={this.onChangeUserPwd}
								required
							/>
						</div>
					</div>

					<div className="form-group row">
						<label for="userpassword" className="col-sm-2 col-form-label">
							Password
						</label>
						<div className="col-sm-10">
							<input
								type="password"
								className="form-control"
								
	 value={this.state.user_mobno}
	onChange={this.onChangeUserMobNo} 
								id="userpassword"
								required
							/>
						</div>
					</div>
					<div class="form-group mt-5">
						<button type="submit" className="btn btn-dark mx-3">
							Submit
						</button>
						<button type="reset" className="btn btn-dark">
							Reset
						</button>
					</div>
				</form>
				<p className="text-center">
					<a href="/signup">Don't have an accountt? Register!</a>
				</p>
			</div>
		);
	}
}