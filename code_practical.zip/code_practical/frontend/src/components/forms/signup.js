import React, {Component} from 'react';
import axios from 'axios';


export default class Signup extends Component{
	
	constructor(props) {
		super(props);

		this.onChangeUserMobNo = this.onChangeUserMobNo.bind(this);
		this.onChangeUserPwd = this.onChangeUserPwd.bind(this);
		this.onChangeUserFname = this.onChangeUserFname.bind(this);
		this.onChangeUserLname = this.onChangeUserLname.bind(this);
		
		this.onSubmit = this.onSubmit.bind(this);

		this.state = {
			user_fname:'',
			user_lname:'',
			user_mobno: '',
			user_pwd: '',
		};
	}

	 onChangeUserMobNo(e) {
        this.setState({
            user_mobno : e.target.value
        });
    }

    onChangeUserPwd(e) {
        this.setState({
            user_pwd: e.target.value
        });
    }
	 onChangeUserFname(e) {
        this.setState({
            user_fname: e.target.value
        });
    } 
	onChangeUserLname(e) {
        this.setState({
            user_lname: e.target.value
        });
    }
	onSubmit(e) {
        e.preventDefault();

        console.log(`user logged in`);
        console.log(`mobno: ${this.state.user_mobno}`);
        console.log(`pwd: ${this.state.user_pwd}`);
		 console.log(`fname: ${this.state.user_fname}`);
        console.log(`lname: ${this.state.user_lname}`);

        const newUser = {
            user_fname: this.state.user_fname,
            user_lname: this.state.user_lname,
            user_mobno: this.state.user_mobno,
            user_pwd: this.state.user_pwd
        }

        axios.post('http://65.0.45.81:55337/signup', newUser)
            .then(res => console.log(res.data));

        this.setState({
            
			user_fname:'',
			user_lname:'',
			user_mobno: '',
			user_pwd: '',
        })
    }
	
	render() {
		return(
		<>
		<div className="login-form jumbotron container">
		  <form onSubmit={this.onSubmit} action="/signup" method="post">
			<h2 className="text-center mb-4">Register</h2>
			
			<div className="form-group row ">
				<label for="fname" className="col-sm-2 col-form-label">First name: </label>
				<div className="col-sm-4">
				  <input type="text" className="form-control" id="fname"
					   value={this.state.user_fname}
                    onChange={this.onChangeUserFname}
					  />
				</div>
				<label for="lname" className="col-sm-2 col-form-label">Last name: </label>
				<div className="col-sm-4">
				  <input type="text" className="form-control" 
					  value={this.state.user_lname}
                    onChange={this.onChangeUserLname}
					  id="lname" />
				</div>
			</div>
			  
			<div className="form-group row ">
				<label for="useremail" className="col-sm-2 col-form-label">Email : </label>
				<div className="col-sm-4">
				  <input type="email" className="form-control" id="useremail" />
				</div>
				
				
				<label for="usermobno" className="col-sm-2 col-form-label">Mobile Number: </label>
				<div className="col-sm-4">
				  <input type="number" className="form-control" 
					  value={this.state.user_mobno}
                    onChange={this.onChangeUserMobNo}
					  id="usermobno" />
				</div>
			</div>
			  
			<div className="form-group row ">
				<label for="userpassword" className="col-sm-2 col-form-label">Password : </label>
				<div className="col-sm-4">
				  <input type="password" className="form-control" 
					  value={this.state.user_pwd}
                    onChange={this.onChangeUserPwd}
					  id="userpassword" />
				</div>
				<label for="userpassword" className="col-sm-2 col-form-label">Confirm Password: </label>
				<div className="col-sm-4">
				  <input type="password" className="form-control" id="userpassword" />
				</div>
			</div>
			 
			  
		
			  
			<div className="form-group row ">
				
				<label for="usergender" className="col-sm-2 col-form-label">Gender: </label>
				<div className="col-sm-4">
					<div className="form-check-inline mt-1">
					 <label className="form-check-label">
					 	<input type="radio" className="form-check-input" name="male" />Male
					  </label>
					</div>
					<div className="form-check-inline">
					  <label className="form-check-label">
					<input type="radio" className="form-check-input" name="female" />Female
					  </label>
					</div>
				</div>
				
				<label for="userprofilephoto" className="col-sm-2 col-form-label">Upload Photo : </label>
				<div className="input-group col-sm-4">
				  
				  <div className="custom-file">
					<input type="file" className="custom-file-input" id="userprofilephoto" aria-describedby="inputGroupFileAddon01" />
					<label className="custom-file-label" for="userprofilephoto">Choose file</label>
				  </div>
				</div>
				
			</div>
			  
			  
			  
			  
			  
			  <div className="form-group row ">
				  
				<label for="usercountry" className="col-sm-2 col-form-label">Country :</label>
				<div className="col-sm-4">
				<select className="custom-select" id="usercountry">
					<option selected>Choose...</option>
					<option value="1">India</option>
					<option value="2">x</option>
					<option value="3">y</option>
			  </select>
				</div>
				  
				<label for="userstate" className="col-sm-2 col-form-label">State :</label>
				<div className="col-sm-4">
				<select className="custom-select" id="userstate">
					<option selected>Choose...</option>
					<option value="1">Rajasthan</option>
					<option value="2">x</option>
					<option value="3">y</option>
			  </select>
				</div>
				
			</div>
			  
			  
			  
			<div className="form-group row ">
				  
				<label for="usercity" className="col-sm-2 col-form-label">City :</label>
				<div className="col-sm-4">
				<select className="custom-select" id="usercity">
					<option selected>Choose...</option>
					<option value="1">Jaipur</option>
					<option value="2">x</option>
					<option value="3">y</option>
			  </select>
				</div>
				  
				<label for="userdob" className="col-sm-2 col-form-label">DOB :</label>
				<div className="col-sm-4">
				<input type="date" id="userdob" name="userdob"/>

				</div>
				
			</div>
	 
			  
			<div className="form-group row ">
				  
				<label for="usercity" className="col-sm-2 col-form-label">Hobbies :</label>
				<div className="col-sm-10">
					<div className="form-check-inline">
					  <input className="form-check-input" type="checkbox" value="" id="defaultCheck1" />
					  <label className="form-check-label" for="defaultCheck1">
						Sports
					  </label>
					</div>
					
					
					<div className="form-check-inline">
					  <input className="form-check-input" type="checkbox" value="" id="defaultCheck2"/>
					  <label className="form-check-label" for="defaultCheck2">
						Movies
					</label>
					</div>
					
					<div className="form-check-inline">
					  <input className="form-check-input" type="checkbox" value="" id="defaultCheck" />
					  <label className="form-check-label" for="defaultCheck3">
						Crafting
					  </label>
					</div>
					
					<div className="form-check-inline">
					  <input className="form-check-input" type="checkbox" value="" id="defaultCheck" />
					  <label className="form-check-label" for="defaultCheck4">
						Playing online games
					  </label>
					</div>
					
					<div className="form-check-inline">
					  <input className="form-check-input" type="checkbox" value="" id="defaultCheck" />
					  <label className="form-check-label" for="defaultCheck3">
						Reading
					  </label>
					</div>
				
					
				</div>
				
			</div>
  
			  <hr />
			<div class="form-group ">
				  <button type="submit" className="btn btn-dark mx-5">Submit</button>
				  <button type="submit" className="btn btn-dark ">Reset</button>
			</div>
		  </form>
		  <p className="text-center">
			<a href="/login">Already have an accountt? Login!</a>
		  </p>
    	</div>
			
		</>
		
		)
	}
}




