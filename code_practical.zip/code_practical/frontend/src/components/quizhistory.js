import React, {Component} from 'react';

export default class Quizhistory extends Component{
	render() {
		return(
			<>
			<div className='jumbotron container mx-auto'>
				<h1 className='mb-5'>Previous attemped quiz history</h1>
				<div className='row'>
				<div className="col-sm-4 mb-5">
						<img src='https://i.pinimg.com/originals/51/f6/fb/51f6fb256629fc755b8870c801092942.png' className='px-3 img-fluid' alt='userimage' style={{height : 40+"px"}}/>	
					</div>

					<div className="col-sm-8 px-5">
						<h1>Welcome User</h1>
						
					</div>
				</div>
				<table className="table table-dark">
				  <thead>
					<tr>
					  <th scope="col">Quiz Id</th>
					  <th scope="col">Score</th>
					  <th scope="col">Create Date</th>
					  <th scope="col">Details</th>
					</tr>
				  </thead>
				  <tbody>
					<tr>
					  <th scope="row">1</th>
					  <td>Mark</td>
					  <td>Otto</td>
					  <td>@mdo</td>
					</tr>
					<tr>
					  <th scope="row">2</th>
					  <td>Jacob</td>
					  <td>Thornton</td>
					  <td>@fat</td>
					</tr>
					<tr>
					  <th scope="row">3</th>
					  <td>Larry</td>
					  <td>the Bird</td>
					  <td>@twitter</td>
					</tr>
				  </tbody>
				</table>
				</div>

				<div>
					
				
			</div>
				
			</>
		)
	}
}