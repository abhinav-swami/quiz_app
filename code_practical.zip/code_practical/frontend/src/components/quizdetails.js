import React, { Component } from "react";

export default class Quizdetails extends Component {
  render() {
    return (
      <>
        <div className="jumbotron container mx-auto">
          <h1 className="mb-5">Quiz details</h1>
          <div className="row">
            <div className="col-sm-4 mb-5">Quiz id: 12345</div>
            <div className="col-sm-4 mb-5">Quiz score: 70</div>
            <div className="col-sm-4 mb-5">
              Attemped on: 15-01-2020 12:12:12
            </div>
          </div>

          <table className="table table-dark">
            <thead>
              <tr>
                <th scope="col">Question</th>
                <th scope="col">Your Answer</th>
                <th scope="col">Correct Answer</th>
                <th scope="col">Score</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <th scope="row">1</th>
                <td>Mark</td>
                <td>Otto</td>
                <td>@mdo</td>
              </tr>
              <tr>
                <th scope="row">2</th>
                <td>Jacob</td>
                <td>Thornton</td>
                <td>@fat</td>
              </tr>
              <tr>
                <th scope="row">3</th>
                <td>Larry</td>
                <td>the Bird</td>
                <td>@twitter</td>
              </tr>
            </tbody>
          </table>

          <table className="table table-dark">
            <tbody>
              <tr>
                <th scope="row">Total</th>
                <td></td>
                <td></td>
                <td>70</td>
              </tr>
            </tbody>
          </table>
        </div>

        <div></div>
      </>
    );
  }
}
