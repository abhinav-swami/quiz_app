const mongoose = require("mongoose");
const Schema = mongoose.Schema;

let userSchema = new Schema({
  user_fname: { type: String },
  user_lname: { type: String },
  user_mobno: { type: Number },
  user_pwd: { type: String }
});

module.exports = mongoose.model("User", userSchema);